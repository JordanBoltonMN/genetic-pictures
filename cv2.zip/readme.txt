cv2.pyd is compiled for Windows Python 2.7 and will not work for any other version.

To install (assuming your requirements match), copy the .pyd file into
.\Lib\site-packages where . is your root Python 2.7 directory.

It is used in the following ways:
    problem.py: cv2.imread
        creates a 3D numpy array using an image file name
    species: cv2.ellipse
        creates an ellipse represented by a 3D numpy array
